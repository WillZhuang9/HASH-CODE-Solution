#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//	Due to this code was finished rushed, there are some detail need to be improve in the future.
//	However, hash code only require us to submit a answer file, which is submission and this program has satified all the data needed
//	Hence, I will point out some thing you need to notice about
//	(1) b.csv is input file. I mean "YOU NEED TO PUT DATA INTO THIS FILE MANUALLY". Beacuse this program is now working as Mathway
//	and I will empty the b.csv file to ensure that you can test it objective.
//	(2) potential bugs in line 23. I don't why this part will keep running in this loop, but work during the data a, b, and c. 
//	So I set a limit here by i == 2 and break it. If it hits a breakpoint, let me know.
//	(3)I didn't allocate the space for array, which will cause a problem in memory leak. As I said, we only need to submit answer by in_file
//	So, if there is a problem caused by meaory leak, let me know
//	principle of opeartion:
//	1. get the two line from b.csv file(string) into array(char)[2] 
//	2. use strtok to seperate the number out and store them into array data[size of type pizza](int)--key point 
//  3. rest of function is based on this array (I will comment below)
int main(void)
{
	FILE* infile = fopen("b.csv", "r");// open the infile to read
	char line[2][200000];// set a char array in two element that contains 2000000 singal char (in order to satisfy the data of part d)
	//line = malloc(sizeof(char)* 100000000*2);
	int i = 0;
	if (infile != NULL)
	{
		while (!feof(infile))
		{
			fgets(line[i], 200000, infile);
			i++;
			if (i == 2)// potential breakpoint 
			{
				break;
			}
		}
	}
	int slice_max, types_pizza;
	slice_max = atoi(strtok(line[0], " "));// get the slice max 
	types_pizza = atoi(strtok(NULL, " "));// get the number of type pizza 
	int data[10000];
	//int n = types_pizza;
	int n = 0;
	while (n < types_pizza)
	{
		if (n == 0)
		{
			data[n] = atoi(strtok(line[1], " "));// the second line from infile, which is a huge data 
		}
		else
		{
			data[n] = atoi(strtok(NULL, " "));
		}
		
		printf("%d\t", data[n]);
		n++;
	}
	n = n - 1;
	int data_total[10000], total = 0;
	int prev = 0;
	i = 0;
	i = n;
	while (n >= 0)// get the sum of result from the last to the first in (pizza_types) results
	{
		while (i >= 0)
		{
			prev = data[i];
			total = prev + total;
			if (total > slice_max)
			{
				total = total - prev;
			}
			i--;
		}
		data_total[n] = total;
		total = 0;
		n--;
		i = n;
	}
	int mark, max;
	max = data_total[0];
	for (n = 0; n <= types_pizza - 1; n++)// compare with those sums and mark the max one 
	{
		if (max < data_total[n + 1])
		{
			max = data_total[n + 1];
			mark = n + 1;
		}
	}
	FILE* outfile = fopen("submission.csv", "w+");
	puts("----------------------------------------------------------------------------------");
	puts("Now is answer");
	system("pause");
	printf("%d\n", max);
	fprintf(outfile, "%d\n", max);//write down on outfile by result of max sum 
	int element[10000], m = 0;
	for (n = mark; n >= 0; n--)//extract the number of combination in the array
	{
		int i = data[n];
		total = total + i;
		if (total > slice_max)
		{
			total = total - i;
		}
		else
		{
			element[m] = i;
			m++;
		}
		n--;
	}
	for (n = m - 1; n >= 0; n--)// write down on output file by result of num in max sum of combination
	{
		printf("%d ", element[n]);
		fprintf(outfile, "%d ", element[n]);
	}
	fclose(infile);
	fclose(outfile);
	return 0;
}